// Copyright 2016, Pulumi Corporation.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package resource

// HookType represents the different types of resource hooks
type HookType string

const (
	BeforeCreate HookType = "BeforeCreate"
	AfterCreate  HookType = "AfterCreate"
	BeforeUpdate HookType = "BeforeUpdate"
	AfterUpdate  HookType = "AfterUpdate"
	BeforeDelete HookType = "BeforeDelete"
	AfterDelete  HookType = "AfterDelete"
	OnError      HookType = "OnError"
)

func IsBeforeHook(hookType HookType) bool {
	return hookType == BeforeCreate || hookType == BeforeUpdate || hookType == BeforeDelete
}

func IsAfterHook(hookType HookType) bool {
	return hookType == AfterCreate || hookType == AfterUpdate || hookType == AfterDelete
}

func IsErrorHook(hookType HookType) bool {
	return hookType == OnError
}
