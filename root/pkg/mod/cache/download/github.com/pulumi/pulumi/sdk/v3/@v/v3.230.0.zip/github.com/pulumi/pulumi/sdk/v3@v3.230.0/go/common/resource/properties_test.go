// Copyright 2016, Pulumi Corporation.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package resource

import (
	"strings"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/common/resource/archive"
	"github.com/pulumi/pulumi/sdk/v3/go/common/resource/asset"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestNewPropertyNonGeneric tests the non-generic NewProperty functions, ensuring they
// behave the same as the generic NewProperty function.
func TestNewPropertyNonGeneric(t *testing.T) {
	t.Parallel()

	assetValue, err := asset.FromText("hello world")
	require.NoError(t, err)

	archiveValue, err := archive.FromAssets(map[string]any{
		"hello": assetValue,
	})
	require.NoError(t, err)

	assert.Equal(t, NewProperty(""), NewStringProperty(""))
	assert.Equal(t, NewProperty("hi"), NewStringProperty("hi"))
	assert.Equal(t, NewProperty(false), NewBoolProperty(false))
	assert.Equal(t, NewProperty(true), NewBoolProperty(true))
	assert.Equal(t, NewProperty(0.0), NewNumberProperty(0))
	assert.Equal(t, NewProperty(42.0), NewNumberProperty(42))
	assert.Equal(t, NewProperty([]PropertyValue{}), NewArrayProperty([]PropertyValue{}))
	assert.Equal(t, NewProperty(assetValue), NewAssetProperty(assetValue))
	assert.Equal(t, NewProperty(archiveValue), NewArchiveProperty(archiveValue))
	assert.Equal(t, NewProperty(PropertyMap{}), NewObjectProperty(PropertyMap{}))
	assert.Equal(t, NewProperty(Computed{Element: NewProperty("")}),
		NewComputedProperty(Computed{Element: NewProperty("")}))
	assert.Equal(t, NewProperty(Output{Element: NewProperty("")}),
		NewOutputProperty(Output{Element: NewProperty("")}))
	assert.Equal(t, NewProperty(&Secret{Element: NewProperty("")}),
		NewSecretProperty(&Secret{Element: NewProperty("")}))
	assert.Equal(t, NewProperty(ResourceReference{}),
		NewResourceReferenceProperty(ResourceReference{}))
}

// TestMappable ensures that we properly convert from resource property maps to their "weakly typed" JSON-like
// equivalents.
func TestMappable(t *testing.T) {
	t.Parallel()

	ma1 := map[string]any{
		"a": float64(42.3),
		"b": false,
		"c": "foobar",
		"d": []any{"x", float64(99), true},
		"e": map[string]any{
			"e.1": "z",
			"e.n": float64(676.767),
			"e.^": []any{"bbb"},
		},
		"f": []any{},
	}
	ma1p := NewPropertyMapFromMap(ma1)
	assert.Equal(t, len(ma1), len(ma1p))
	ma1mm := ma1p.Mappable()
	assert.Equal(t, ma1, ma1mm)
}

// TestMapReplValues ensures that we properly convert from resource property maps to their "weakly typed" JSON-like
// equivalents, but with additional and optional functions that replace values inline as we go.
func TestMapReplValues(t *testing.T) {
	t.Parallel()

	// First, no replacements (nil repl).
	ma1 := map[string]any{
		"a": float64(42.3),
		"b": false,
		"c": "foobar",
		"d": []any{"x", float64(99), true},
		"e": map[string]any{
			"e.1": "z",
			"e.n": float64(676.767),
			"e.^": []any{"bbb"},
		},
	}
	ma1p := NewPropertyMapFromMap(ma1)
	assert.Equal(t, len(ma1), len(ma1p))
	ma1mm := ma1p.MapRepl(nil, nil)
	assert.Equal(t, ma1, ma1mm)

	// First, no replacements (false-returning repl).
	ma2 := map[string]any{
		"a": float64(42.3),
		"b": false,
		"c": "foobar",
		"d": []any{"x", float64(99), true},
		"e": map[string]any{
			"e.1": "z",
			"e.n": float64(676.767),
			"e.^": []any{"bbb"},
		},
	}
	ma2p := NewPropertyMapFromMap(ma2)
	assert.Equal(t, len(ma2), len(ma2p))
	ma2mm := ma2p.MapRepl(nil, func(v PropertyValue) (any, bool) {
		return nil, false
	})
	assert.Equal(t, ma2, ma2mm)

	// Finally, actually replace some numbers with ints.
	ma3 := map[string]any{
		"a": float64(42.3),
		"b": false,
		"c": "foobar",
		"d": []any{"x", float64(99), true},
		"e": map[string]any{
			"e.1": "z",
			"e.n": float64(676.767),
			"e.^": []any{"bbb"},
		},
	}
	ma3p := NewPropertyMapFromMap(ma3)
	assert.Equal(t, len(ma3), len(ma3p))
	ma3mm := ma3p.MapRepl(nil, func(v PropertyValue) (any, bool) {
		if v.IsNumber() {
			return int(v.NumberValue()), true
		}
		return nil, false
	})
	// patch the original map so it can compare easily
	ma3["a"] = int(ma3["a"].(float64))
	ma3["d"].([]any)[1] = int(ma3["d"].([]any)[1].(float64))
	ma3["e"].(map[string]any)["e.n"] = int(ma3["e"].(map[string]any)["e.n"].(float64))
	assert.Equal(t, ma3, ma3mm)
}

func TestMapReplKeys(t *testing.T) {
	t.Parallel()

	m := map[string]any{
		"a": float64(42.3),
		"b": false,
		"c": "foobar",
		"d": []any{"x", float64(99), true},
		"e": map[string]any{
			"e.1": "z",
			"e.n": float64(676.767),
			"e.^": []any{"bbb"},
		},
	}
	ma := NewPropertyMapFromMap(m)
	assert.Equal(t, len(m), len(ma))
	mam := ma.MapRepl(func(k string) (string, bool) {
		return strings.ToUpper(k), true
	}, nil)
	assert.Equal(t, m["a"], mam["A"])
	assert.Equal(t, m["b"], mam["B"])
	assert.Equal(t, m["c"], mam["C"])
	assert.Equal(t, m["d"], mam["D"])
	assert.Equal(t, m["e"].(map[string]any)["e.1"], mam["E"].(map[string]any)["E.1"])
	assert.Equal(t, m["e"].(map[string]any)["e.n"], mam["E"].(map[string]any)["E.N"])
	assert.Equal(t, m["e"].(map[string]any)["e.^"], mam["E"].(map[string]any)["E.^"])
}

func TestMapReplComputedOutput(t *testing.T) {
	t.Parallel()

	m := make(PropertyMap)
	m["a"] = NewProperty(Computed{Element: NewProperty("X")})
	m["b"] = NewProperty(Output{Element: NewProperty(46.0)})
	mm := m.MapRepl(nil, nil)
	assert.Equal(t, len(m), len(mm))
	m2 := NewPropertyMapFromMap(mm)
	assert.Equal(t, m, m2)
}

func TestCopy(t *testing.T) {
	t.Parallel()

	src := NewPropertyMapFromMap(map[string]any{
		"a": "str",
		"b": 42,
	})
	dst := src.Copy()
	require.NotNil(t, dst)
	assert.Equal(t, len(src), len(dst))
	assert.Equal(t, src["a"], dst["a"])
	assert.Equal(t, src["b"], dst["b"])
	src["a"] = NewNullProperty()
	assert.Equal(t, NewProperty("str"), dst["a"])
	src["c"] = NewProperty(99.99)
	require.Len(t, dst, 2)
}

func TestSecretUnknown(t *testing.T) {
	t.Parallel()

	o := NewProperty(Output{Element: NewProperty(46.0)})
	so := MakeSecret(o)
	assert.True(t, o.ContainsUnknowns())
	assert.True(t, so.ContainsUnknowns())
	c := NewProperty(Computed{Element: NewProperty("X")})
	co := MakeSecret(so)
	assert.True(t, c.ContainsUnknowns())
	assert.True(t, co.ContainsUnknowns())
}

func TestTypeString(t *testing.T) {
	t.Parallel()

	tests := []struct {
		prop     PropertyValue
		expected string
	}{
		{
			prop:     MakeComputed(NewProperty("")),
			expected: "output<string>",
		},
		{
			prop:     MakeSecret(NewProperty("")),
			expected: "secret<string>",
		},
		{
			prop:     MakeOutput(NewProperty("")),
			expected: "output<string>",
		},
		{
			prop: NewProperty(Output{
				Element: NewProperty(""),
				Known:   true,
			}),
			expected: "string",
		},
		{
			prop: NewProperty(Output{
				Element: NewProperty(""),
				Known:   true,
				Secret:  true,
			}),
			expected: "secret<string>",
		},
	}
	for _, tt := range tests {
		t.Run(tt.expected, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tt.expected, tt.prop.TypeString())
		})
	}
}

func TestString(t *testing.T) {
	t.Parallel()

	tests := []struct {
		prop     PropertyValue
		expected string
	}{
		{
			prop:     MakeComputed(NewProperty("")),
			expected: "output<string>{}",
		},
		{
			prop:     MakeSecret(NewProperty("shh")),
			expected: "{&{{shh}}}",
		},
		{
			prop:     MakeOutput(NewProperty("")),
			expected: "output<string>{}",
		},
		{
			prop: NewProperty(Output{
				Element: NewProperty("hello"),
				Known:   true,
			}),
			expected: "{hello}",
		},
		{
			prop: NewProperty(Output{
				Element: NewProperty("shh"),
				Known:   true,
				Secret:  true,
			}),
			expected: "{&{{shh}}}",
		},
	}
	for _, tt := range tests {
		t.Run(tt.expected, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tt.expected, tt.prop.String())
		})
	}
}

func TestRedactSecrets(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		prop     PropertyValue
		expected string
	}{
		{
			name:     "computed",
			prop:     MakeComputed(NewProperty("")),
			expected: "output<string>{}",
		},
		{
			name:     "secret string",
			prop:     MakeSecret(NewProperty("shh")),
			expected: "{[secret]}",
		},
		{
			name:     "plain string",
			prop:     NewProperty("hello"),
			expected: "{hello}",
		},
		{
			name:     "output unknown",
			prop:     MakeOutput(NewProperty("")),
			expected: "output<string>{}",
		},
		{
			name: "output known",
			prop: NewProperty(Output{
				Element: NewProperty("hello"),
				Known:   true,
			}),
			expected: "{hello}",
		},
		{
			name: "output secret",
			prop: NewProperty(Output{
				Element: NewProperty("shh"),
				Known:   true,
				Secret:  true,
			}),
			expected: "{[secret]}",
		},
		{
			name: "object with nested secret",
			prop: NewProperty(PropertyMap{
				"plain":  NewProperty("visible"),
				"secret": MakeSecret(NewProperty("hidden")),
			}),
			expected: "{map[plain:{visible} secret:{[secret]}]}",
		},
		{
			name: "array with nested secret",
			prop: NewProperty([]PropertyValue{
				NewProperty("visible"),
				MakeSecret(NewProperty("hidden")),
			}),
			expected: "{[{visible} {[secret]}]}",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			require.Equal(t, tt.expected, tt.prop.RedactSecrets())
		})
	}
}

func TestContainsUnknowns(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		prop     PropertyValue
		expected bool
	}{
		{
			name:     "computed unknown",
			prop:     MakeComputed(NewProperty("")),
			expected: true,
		},
		{
			name:     "output unknown",
			prop:     MakeOutput(NewProperty("")),
			expected: true,
		},
		{
			name: "output known",
			prop: NewProperty(Output{
				Element: NewProperty(""),
				Known:   true,
			}),
			expected: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tt.expected, tt.prop.ContainsUnknowns())
		})
	}
}

func TestContainsSecrets(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		prop     PropertyValue
		expected bool
	}{
		{
			name:     "secret",
			prop:     MakeSecret(NewProperty("")),
			expected: true,
		},
		{
			name:     "output unknown",
			prop:     MakeOutput(NewProperty("")),
			expected: false,
		},
		{
			name:     "output unknown containing secret",
			prop:     MakeOutput(MakeSecret(NewProperty(""))),
			expected: true,
		},
		{
			name: "output unknown secret",
			prop: NewProperty(Output{
				Element: NewProperty(""),
				Secret:  true,
			}),
			expected: true,
		},
		{
			name: "output known secret",
			prop: NewProperty(Output{
				Element: NewProperty(""),
				Known:   true,
				Secret:  true,
			}),
			expected: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tt.expected, tt.prop.ContainsSecrets())
		})
	}
}

func TestHasValue(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		prop     PropertyValue
		expected bool
	}{
		{
			name:     "null",
			prop:     NewNullProperty(),
			expected: false,
		},
		{
			name:     "string",
			prop:     NewProperty(""),
			expected: true,
		},
		{
			name:     "output unknown",
			prop:     MakeOutput(NewProperty("")),
			expected: false,
		},
		{
			name: "output known",
			prop: NewProperty(Output{
				Element: NewProperty(""),
				Known:   true,
			}),
			expected: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			assert.Equal(t, tt.expected, tt.prop.HasValue())
		})
	}
}

// Test for https://github.com/pulumi/pulumi/issues/16889
func TestMapFromMapNestedPropertyValues(t *testing.T) {
	t.Parallel()

	actual := NewPropertyMapFromMap(map[string]any{
		"prop": NewProperty("value"),
		"nested": map[string]any{
			"obj": NewProperty(PropertyMap{
				"k": NewProperty("v"),
			}),
		},
	})

	expected := PropertyMap{
		"prop": NewProperty("value"),
		"nested": NewProperty(PropertyMap{
			"obj": NewProperty(PropertyMap{
				"k": NewProperty("v"),
			}),
		}),
	}

	assert.Equal(t, expected, actual)
}
