// Copyright 2025, Pulumi Corporation.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package registry

import "testing"

func TestIsPreRegistryPackage(t *testing.T) {
	t.Parallel()

	testCases := []struct {
		name     string
		expected bool
	}{
		// Pre-registry packages
		{"aws", true},
		{"azure", true},
		{"kubernetes", true},
		{"gcp", true},
		{"random", true},

		// Case-insensitive
		{"AWS", true},
		{"Azure", true},
		{"KUBERNETES", true},

		// Unknown packages
		{"stackmgmt", false},
		{"unknown-package", false},
		{"my-custom-provider", false},
		{"", false},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			result := IsPreRegistryPackage(tc.name)
			if result != tc.expected {
				t.Errorf("IsPreRegistryPackage(%q) = %v, expected %v", tc.name, result, tc.expected)
			}
		})
	}
}
